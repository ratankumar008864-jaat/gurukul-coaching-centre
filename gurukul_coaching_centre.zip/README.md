# Gurukul Coaching Centre
Fresh static website for Gurukul Coaching Centre.

Features:
- Student biodata table
- Search by name/mobile
- Monthly tuition fee: ₹1,000
- UPI payment button
- Payment number and UPI ID section
- Responsive mobile design

Open `index.html` in a browser to test.
